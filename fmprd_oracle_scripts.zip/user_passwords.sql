set pagesize 500
set linesize 200
set trimspool on
select username as USER_NAME, expiry_date as EXPIRE_DATE, account_status
from dba_users
where expiry_date < sysdate+120
and account_status IN ( 'OPEN', 'EXPIRED(GRACE)' )
order by account_status, expiry_date, username
/
