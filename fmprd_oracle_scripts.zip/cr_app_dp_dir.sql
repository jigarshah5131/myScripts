exec rdsadmin.rdsadmin_util.create_directory(p_directory_name => 'APP_DP_DIR');
grant read,write on directory app_dp_dir to APP_RW_DIR_ROLE;
