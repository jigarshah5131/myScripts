set pages 10000
set lines 300
set head on
set echo off
column object_count format 999999999999
column username format a30
column account_status format a30
column expiry_date format a15
column profile format a30

select instance_name,host_name,version from v$instance;

select a.username,a.account_status,a.expiry_date, b.object_count, a.profile
from dba_users a,
(select owner username,count(1) object_count
from dba_objects
where owner not in ('DBADMIN','RDSADMIN','AWSDBA','FFMDBA')
group by owner) b
where a.oracle_maintained = 'N'
and a.username = b.username;
