create user deyanja identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;
create user qaziali identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;
create user phanduy identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;
create user waltzia identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;
create user goredev identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;
create user aghaeea identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;
create user balaanb identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;
create user nandsri identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;
create user lilily identified by Hot_Summer_FM_2018 default tablespace users temporary tablespace temp quota unlimited on users;

grant eps_reader,eps_app_role,pay_app_reader,edge_app_role,pay_app_role,cms_connect,edge_reader to waltzia,deyanja,qaziali,phanduy,goredev,aghaeea,balaanb,lilily,nandsri;
