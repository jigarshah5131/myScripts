set pages 100 set lines 150 
spool drop_cons_1_eps.sql
select 'alter table '
       ||owner||'.'|| table_name
       || ' drop constraint '
       || constraint_name
       ||';' constraint_disable
from all_constraints
where constraint_type = 'R'
and status = 'ENABLED'
and r_constraint_name in
 (
   select constraint_name
   from all_constraints
   where constraint_type in ('P', 'U')
   and table_name in ('TRANSMSG','TRANSMSGDIRECTIONTYPE','TRANSMSGTYPE','TRANSMSGFILEINFO')
 )
/
spool off
