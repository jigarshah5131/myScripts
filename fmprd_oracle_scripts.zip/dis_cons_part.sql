alter table EPS_OWNER.TRANSMSG_PART disable constraint R_81P;
alter table EPS_OWNER.TRANSMSG_PART disable constraint R_39P;
alter table EPS_OWNER.TRANSMSG_PART disable constraint R_40P;
alter table EPS_OWNER.TRANSMSG_PART disable constraint R_38P;
