set feed on
set pages 1000
set lines 120
cle bre
col sid form 9999
col start_time head "Start|Time" form a12 trunc
col opname head "Operation" form a12 trunc
col target head "Object" form a30 wrap
col units head "Work|Units" form a8
col totalwork head "Total|Work" form 999,999,999 trunc
col Sofar head "Sofar" form 99,999,999 trunc
col elamin head "Ela|psed|Time|(Mins)" form 99,999 trunc
col estmin head "Est|Time|My|Estimate|(Mins)" form 99,999 trunc
col tre head "Est|Time|Remain|(Mins)" form 999,999 trunc

select  sid,
        to_char(start_time,'dd-mon:hh24:mi') start_time,
        opname,
        target,
        units,
        totalwork,
        sofar,
        (elapsed_Seconds/60) elamin,
        ((totalwork-sofar)*elapsed_Seconds/sofar)/60 estmin,
        time_remaining tre
from gv$session_longops
where totalwork<>sofar
order by start_time,Sofar
/
