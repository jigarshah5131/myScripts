select table_name,num_rows,chain_cnt,last_analyzed,sample_size,stale_stats from dba_tab_statistics where owner='EPS_OWNER' and object_type='TABLE' order by 4
/
