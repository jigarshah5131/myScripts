select substr(regexp_substr(PHYSICAL_DOCUMENT_FILE_NAME,'D.+T'),-5) from edge_owner.physical_document_file where EDGE_JOB_FILE_TYPE_CD like 'RARSS' and PHYSICAL_DOCUMENT_FILE_NAME not like '%D201%'
--select regexp_substr(PHYSICAL_DOCUMENT_FILE_NAME,'20.+T',1) from edge_owner.physical_document_file where EDGE_JOB_FILE_TYPE_CD like 'RARSS' and PHYSICAL_DOCUMENT_FILE_NAME not like '%D201%'
/
