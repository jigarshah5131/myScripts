exec rdsadmin.rdsadmin_util.switch_logfile;
exec rdsadmin.rdsadmin_util.drop_logfile(grp =>?);
exec rdsadmin.rdsadmin_util.add_logfile(p_size => '2G');
