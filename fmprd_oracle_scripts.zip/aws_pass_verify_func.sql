begin
    rdsadmin.rdsadmin_password_verify.create_verify_function(
        p_verify_function_name => 'STRONG_PASSWORD_FUNCTION', 
        p_min_length           => 15, 
        p_min_uppercase        => 3, 
        p_min_lowercase        => 3, 
        p_min_digits           => 3, 
        p_min_special          => 3,
        p_disallow_at_sign     => true);
end;
/
