select event, state, count(*) from v$session_wait group by event, state order by 3 desc;

select
	count(*),
	CASE WHEN state != 'WAITING' THEN 'WORKING'
	ELSE 'WAITING'
	END AS state,
	CASE WHEN state != 'WAITING' THEN 'On CPU / runqueue'
	ELSE event
	END AS sw_event
FROM
	v$session_wait
GROUP BY
	CASE WHEN state != 'WAITING' THEN 'WORKING'
	ELSE 'WAITING'
	END,
	CASE WHEN state != 'WAITING' THEN 'On CPU / runqueue'
	ELSE event
	END
ORDER BY 1 DESC, 2 DESC
/
select
     count(*),
     CASE WHEN state != 'WAITING' THEN 'WORKING'
          ELSE 'WAITING'
     END AS state,
     CASE WHEN state != 'WAITING' THEN 'On CPU / runqueue'
          ELSE event
     END AS sw_event
  FROM
     v$session
  WHERE
      type = 'USER'
  AND status = 'ACTIVE'
  GROUP BY
     CASE WHEN state != 'WAITING' THEN 'WORKING'
          ELSE 'WAITING'
     END,
     CASE WHEN state != 'WAITING' THEN 'On CPU / runqueue'
          ELSE event
     END
  ORDER BY
     1 DESC, 2 DESC
  /
select sql_hash_value, count(*) from v$session
   where status = 'ACTIVE' group by sql_hash_value order by 2 desc;

