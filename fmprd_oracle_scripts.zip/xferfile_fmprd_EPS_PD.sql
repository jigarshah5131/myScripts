--grant read,write on directory data_pump_d
--select * from table(RDSADMIN.RDS_FILE_UTIL.LISTDIR('DATA_PUMP_DIR')) order by mtime;
begin
  dbms_file_transfer.put_file(
  SOURCE_DIRECTORY_OBJECT => 'DATA_PUMP_DIR',
  SOURCE_FILE_NAME => 'FMPRD_EPS_OWNER_100618_PHY_DOC.dmp',
  DESTINATION_DIRECTORY_OBJECT => 'DATA_PUMP_DIR',
  DESTINATION_FILE_NAME => 'FMPRD_EPS_OWNER_100618_PHY_DOC.dmp',
  DESTINATION_DATABASE =>'XFER_FMPRD_RDS'
  );
end;
/
