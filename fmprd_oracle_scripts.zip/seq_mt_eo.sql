col sequence_name format a30
col table_name format a30
col column_name format a30
set serveroutput on
declare
 maxval1 int;
 seqval int;
 begin
    dbms_output.put_line('maxval1,seqval');
 for i in ( select uc.owner,ucc.column_name, s.sequence_name, uc.table_name,s.sequence_owner
 from   dba_cons_columns ucc,
 dba_constraints uc,
 	dba_sequences s
 	where  uc.constraint_name = ucc.constraint_name
             and    uc.constraint_type = 'P'
             and    ucc.position = 1
             and    s.sequence_name = uc.table_name||'SEQ'
             and    s.sequence_owner = 'EPS_OWNER'
--             and    uc.table_name not in ('REFDATA_VER','SQL_DOCUMENT_FILE')
           )
  loop
     execute immediate  'select max('||i.column_name||') from '||i.owner||'.'||i.table_name into maxval1;
    execute immediate 'select '||i.sequence_owner||'.'||i.sequence_name||'.nextval from dual' into seqval;
    dbms_output.put_line(maxval1||','||seqval);
     if maxval1 > seqval then
        execute immediate  'alter sequence '||i.sequence_owner||'.'||i.sequence_name||' increment by '|| ( maxval1 - seqval );
        execute immediate 'select '||i.sequence_owner||'.'||i.sequence_name||'.nextval from dual' into seqval;
        execute immediate  'alter sequence '||i.sequence_owner||'.'||i.sequence_name||' increment by 1';
        execute immediate 'select '||i.sequence_owner||'.'||i.sequence_name||'.nextval from dual' into seqval;
        dbms_output.put_line(maxval1||','||seqval);
     end if;
  end loop;
end;
/
