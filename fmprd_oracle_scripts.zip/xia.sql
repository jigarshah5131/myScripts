set lines 210
prompt Display Execution plan in advanced format for sqlid &1

--select * from table(dbms_xplan.display_cursor('&1',null,'ADVANCED +ALLSTATS LAST +PEEKED_BINDS'));
--select * from table(dbms_xplan.display_cursor('&1',null,'ADVANCED +ALLSTATS LAST'));
--select * from table(dbms_xplan.display_awr('&1','&2',null,'ADVANCED +ALLSTATS LAST +PEEKED_BINDS'));
select * from table(dbms_xplan.display_awr('&1',null,null,'ADVANCED'));
