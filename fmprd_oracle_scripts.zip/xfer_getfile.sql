--grant read,write on directory data_pump_d
--select * from table(RDSADMIN.RDS_FILE_UTIL.LISTDIR('DATA_PUMP_DIR')) order by mtime;
BEGIN
  DBMS_FILE_TRANSFER.get_file(
   source_directory_object      => 'DATA_PUMP_DIR',
   source_file_name             => 'exp_opera_6438.dmp',
   source_database              => 'XFER_RDS_FMPRD',
   destination_directory_object => 'DATA_PUMP_DIR',
   destination_file_name        => 'exp_opera_6438.dmp');
END;
/
BEGIN
  DBMS_FILE_TRANSFER.get_file(
   source_directory_object      => 'DATA_PUMP_DIR',
   source_file_name             => 'tempadmin.dmp',
   source_database              => 'to_rds',
   destination_directory_object => 'DATA_PUMP_DIR',
   destination_file_name        => 'tempadmin_from_rds.dmp');
END;
/
