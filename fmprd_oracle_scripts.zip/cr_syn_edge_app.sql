SQL> l
  1* select 'create synonym edge_app.'||table_name|| ' for edge_owner.'||table_name||';' from dba_tables where owner='EDGE_OWNER'
SQL> /

'CREATESYNONYMEDGE_APP.'||TABLE_NAME||'FOREDGE_OWNER.'||TABLE_NAME||';'                                                                               
------------------------------------------------------------------------------------------------------------------------------------------------------
create synonym edge_app.SERVER_REQUEST_STATUS_TYPE for edge_owner.SERVER_REQUEST_STATUS_TYPE;                                                         
create synonym edge_app.SERVER_REQUEST_ERROR_LOG for edge_owner.SERVER_REQUEST_ERROR_LOG;                                                             
create synonym edge_app.JOB_EXECUTION for edge_owner.JOB_EXECUTION;                                                                                   
create synonym edge_app.JOB_EXECUTION_FILE for edge_owner.JOB_EXECUTION_FILE;                                                                         
create synonym edge_app.EDGE_SERVER_DETAIL for edge_owner.EDGE_SERVER_DETAIL;                                                                         
create synonym edge_app.ACCESS_KEY_UPDATE for edge_owner.ACCESS_KEY_UPDATE;                                                                           
create synonym edge_app.EDGE_BATCH for edge_owner.EDGE_BATCH;                                                                                         
create synonym edge_app.EDGE_JOB_EXECUTION for edge_owner.EDGE_JOB_EXECUTION;                                                                         
create synonym edge_app.EDGE_JOB_RMT_CMD for edge_owner.EDGE_JOB_RMT_CMD;                                                                             
create synonym edge_app.EDGE_SERVER_VERSION for edge_owner.EDGE_SERVER_VERSION;                                                                       
create synonym edge_app.EXCHANGE_USER for edge_owner.EXCHANGE_USER;                                                                                   
create synonym edge_app.EDGE_BATCH_STATUSYAU83024010 for edge_owner.EDGE_BATCH_STATUSYAU83024010;                                                     
create synonym edge_app.EDGE_SERVER_STATUSYAU83024013 for edge_owner.EDGE_SERVER_STATUSYAU83024013;                                                   
create synonym edge_app.EDGE_JOB_EXECUTIONYAU83024011 for edge_owner.EDGE_JOB_EXECUTIONYAU83024011;                                                   
create synonym edge_app.EDGE_JOB_RMT_CMD_SYAU83024012 for edge_owner.EDGE_JOB_RMT_CMD_SYAU83024012;                                                   
create synonym edge_app.EDGE_BATCH_ISSUER for edge_owner.EDGE_BATCH_ISSUER;                                                                           
create synonym edge_app.ISSUER_EDGE_SERVER_YEAR for edge_owner.ISSUER_EDGE_SERVER_YEAR;                                                               
create synonym edge_app.PHYSICAL_DOCUMENT_FILE_STATUS for edge_owner.PHYSICAL_DOCUMENT_FILE_STATUS;                                                   
create synonym edge_app.SERVER_REQUEST for edge_owner.SERVER_REQUEST;                                                                                 
create synonym edge_app.SERVER_REQUEST_STATUS for edge_owner.SERVER_REQUEST_STATUS;                                                                   
create synonym edge_app.SERVER_REQUEST_POC for edge_owner.SERVER_REQUEST_POC;                                                                         
create synonym edge_app.COMMENT_HISTORY for edge_owner.COMMENT_HISTORY;                                                                               
create synonym edge_app.EDGE_SERVER_POC for edge_owner.EDGE_SERVER_POC;                                                                               
create synonym edge_app.EDGE_JOB_RMT_CMD_FILE for edge_owner.EDGE_JOB_RMT_CMD_FILE;                                                                   
create synonym edge_app.EDGE_BATCH_STATUS for edge_owner.EDGE_BATCH_STATUS;                                                                           
create synonym edge_app.EDGE_JOB_EXECUTION_STATUS for edge_owner.EDGE_JOB_EXECUTION_STATUS;                                                           
create synonym edge_app.EDGE_JOB_RMT_CMD_STATUS for edge_owner.EDGE_JOB_RMT_CMD_STATUS;                                                               
create synonym edge_app.EDGE_SERVER_STATUS for edge_owner.EDGE_SERVER_STATUS;                                                                         
create synonym edge_app.EDGE_JOB_SQL_FILE for edge_owner.EDGE_JOB_SQL_FILE;                                                                           
create synonym edge_app.SQL_FILE_INFO_STATUS for edge_owner.SQL_FILE_INFO_STATUS;                                                                     
create synonym edge_app.ZONE_TYPE for edge_owner.ZONE_TYPE;                                                                                           
create synonym edge_app.REFDATA_FILE_TYPE for edge_owner.REFDATA_FILE_TYPE;                                                                           
create synonym edge_app.REFDATA_VERSION_FILE_INFO for edge_owner.REFDATA_VERSION_FILE_INFO;                                                           
create synonym edge_app.EDGE_REFDATA_FILE for edge_owner.EDGE_REFDATA_FILE;                                                                           
create synonym edge_app.EDGE_SERVER_REFDATA_VERSION for edge_owner.EDGE_SERVER_REFDATA_VERSION;                                                       
create synonym edge_app.CLAIM_BILL_TYPE for edge_owner.CLAIM_BILL_TYPE;                                                                               
create synonym edge_app.SRVC_CD_MDFR_TYPE for edge_owner.SRVC_CD_MDFR_TYPE;                                                                           
create synonym edge_app.DSCHRG_STUS_TYPE for edge_owner.DSCHRG_STUS_TYPE;                                                                             
create synonym edge_app.DGNS_CD_TYPE for edge_owner.DGNS_CD_TYPE;                                                                                     
create synonym edge_app.REV_CD_TYPE for edge_owner.REV_CD_TYPE;                                                                                       
create synonym edge_app.SRVC_PLC_TYPE for edge_owner.SRVC_PLC_TYPE;                                                                                   
create synonym edge_app.ENRL_DGNS_CD_TO_CC_CD_ASSOC for edge_owner.ENRL_DGNS_CD_TO_CC_CD_ASSOC;                                                       
create synonym edge_app.INFANT_DIAG_CODES for edge_owner.INFANT_DIAG_CODES;                                                                           
create synonym edge_app.ENRL_COST_SHARE_RDCTN for edge_owner.ENRL_COST_SHARE_RDCTN;                                                                   
create synonym edge_app.ENROLLMENT_DURATION_FACTOR for edge_owner.ENROLLMENT_DURATION_FACTOR;                                                         
create synonym edge_app.ENRL_DEMOGRAPHIC_FACTOR for edge_owner.ENRL_DEMOGRAPHIC_FACTOR;                                                               
create synonym edge_app.ENRLAGE_TYPEHCCGCC_MTLLVLASSOC for edge_owner.ENRLAGE_TYPEHCCGCC_MTLLVLASSOC;                                                 
create synonym edge_app.ENRL_INFNT_SVRTY_MTRTY_FACTOR for edge_owner.ENRL_INFNT_SVRTY_MTRTY_FACTOR;                                                   
create synonym edge_app.ENRL_ADLT_MDL_FACTOR for edge_owner.ENRL_ADLT_MDL_FACTOR;                                                                     
create synonym edge_app.ENRL_HCC_CC_TO_EXCLUDE_ASSOC for edge_owner.ENRL_HCC_CC_TO_EXCLUDE_ASSOC;                                                     
create synonym edge_app.ENRL_RISK_REINSRNC_ATTR for edge_owner.ENRL_RISK_REINSRNC_ATTR;                                                               
create synonym edge_app.ENRL_RISK_RIAR_ATTR for edge_owner.ENRL_RISK_RIAR_ATTR;                                                                       
create synonym edge_app.ENRL_AFF_CARE_ACT_AGE_RATE for edge_owner.ENRL_AFF_CARE_ACT_AGE_RATE;                                                         
create synonym edge_app.ENRL_RA_TRANSFER for edge_owner.ENRL_RA_TRANSFER;                                                                             
create synonym edge_app.ENRL_INFNT_HCC_SVRTY_ASSOC for edge_owner.ENRL_INFNT_HCC_SVRTY_ASSOC;                                                         
create synonym edge_app.ENRL_INFNT_CC_MATURITY_ASSOC for edge_owner.ENRL_INFNT_CC_MATURITY_ASSOC;                                                     
create synonym edge_app.ENRL_HCC_GC_SVRTY_ASSOC for edge_owner.ENRL_HCC_GC_SVRTY_ASSOC;                                                               
create synonym edge_app.ENRL_CNDTN_CTGRY_CD for edge_owner.ENRL_CNDTN_CTGRY_CD;                                                                       
create synonym edge_app.ENRL_GRP_CD_HCC_CD_ASSOC for edge_owner.ENRL_GRP_CD_HCC_CD_ASSOC;                                                             
create synonym edge_app.USER_FEE_RATE for edge_owner.USER_FEE_RATE;                                                                                   
create synonym edge_app.NDC_CD_TYPE for edge_owner.NDC_CD_TYPE;                                                                                       
create synonym edge_app.ERROR_LEVEL_TYPE for edge_owner.ERROR_LEVEL_TYPE;                                                                             
create synonym edge_app.SERVER_REQUEST_ERROR_TYPE for edge_owner.SERVER_REQUEST_ERROR_TYPE;                                                           
create synonym edge_app.JOB_TYPE for edge_owner.JOB_TYPE;                                                                                             
create synonym edge_app.EDGE_BATCH_STATUS_TYPE for edge_owner.EDGE_BATCH_STATUS_TYPE;                                                                 
create synonym edge_app.EDGE_BATCH_TYPE for edge_owner.EDGE_BATCH_TYPE;                                                                               
create synonym edge_app.EDGE_JOB_EXECUTION_STATUS_TYPE for edge_owner.EDGE_JOB_EXECUTION_STATUS_TYPE;                                                 
create synonym edge_app.EDGE_JOB_EXECUTION_TYPE for edge_owner.EDGE_JOB_EXECUTION_TYPE;                                                               
create synonym edge_app.EDGE_JOB_FILE_TYPE for edge_owner.EDGE_JOB_FILE_TYPE;                                                                         
create synonym edge_app.EDGE_SERVER_TYPE for edge_owner.EDGE_SERVER_TYPE;                                                                             
create synonym edge_app.EDGE_JOB_RMT_CMD_STATUS_TYPE for edge_owner.EDGE_JOB_RMT_CMD_STATUS_TYPE;                                                     
create synonym edge_app.EDGE_JOB_RMT_CMD_TYPE for edge_owner.EDGE_JOB_RMT_CMD_TYPE;                                                                   
create synonym edge_app.EDGE_SERVER_STATUS_TYPE for edge_owner.EDGE_SERVER_STATUS_TYPE;                                                               
create synonym edge_app.EXCHANGE_USER_PRIORITY_TYPE for edge_owner.EXCHANGE_USER_PRIORITY_TYPE;                                                       
create synonym edge_app.EXCHANGE_USER_ROLE_TYPE for edge_owner.EXCHANGE_USER_ROLE_TYPE;                                                               
create synonym edge_app.ISSUER_LIST_TYPE for edge_owner.ISSUER_LIST_TYPE;                                                                             
create synonym edge_app.NOTE for edge_owner.NOTE;                                                                                                     
create synonym edge_app.ORGANIZATION for edge_owner.ORGANIZATION;                                                                                     
create synonym edge_app.ORGANIZATION_TYPE for edge_owner.ORGANIZATION_TYPE;                                                                           
create synonym edge_app.PERIOD_CYCLE_QUARTER_TYPE for edge_owner.PERIOD_CYCLE_QUARTER_TYPE;                                                           
create synonym edge_app.PERIOD_CYCLE_YEAR_TYPE for edge_owner.PERIOD_CYCLE_YEAR_TYPE;                                                                 
create synonym edge_app.PHYSICAL_DOCUMENT_MEDIA_TYPE for edge_owner.PHYSICAL_DOCUMENT_MEDIA_TYPE;                                                     
create synonym edge_app.PHYSICAL_DOCUMENT_STATUS_TYPE for edge_owner.PHYSICAL_DOCUMENT_STATUS_TYPE;                                                   
create synonym edge_app.POINT_OF_CONTACT_TYPE for edge_owner.POINT_OF_CONTACT_TYPE;                                                                   
create synonym edge_app.STATE_POSTAL for edge_owner.STATE_POSTAL;                                                                                     
create synonym edge_app.TRANSACTION_MESSAGE_DRCTN_TP for edge_owner.TRANSACTION_MESSAGE_DRCTN_TP;                                                     
create synonym edge_app.SRVC_CD_TYPE for edge_owner.SRVC_CD_TYPE;                                                                                     
create synonym edge_app.DATA_AGREEMENT for edge_owner.DATA_AGREEMENT;                                                                                 
create synonym edge_app.PHYSICAL_DOCUMENT_FILE for edge_owner.PHYSICAL_DOCUMENT_FILE;                                                                 
create synonym edge_app.EDGE_OWNER_STATS for edge_owner.EDGE_OWNER_STATS;                                                                             
create synonym edge_app.SQL_FILE_INFO for edge_owner.SQL_FILE_INFO;                                                                                   
create synonym edge_app.SQL_INVENTORY for edge_owner.SQL_INVENTORY;                                                                                   
create synonym edge_app.REFDATA_VERSION_INFO for edge_owner.REFDATA_VERSION_INFO;                                                                     

93 rows selected.

SQL> spool off
