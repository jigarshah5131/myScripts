--SQL> l
--  1* select 'drop sequence edge_owner.'||sequence_name||';' from dba_sequences where  sequence_owner='EDGE_OWNER'
--SQL> /
--
--'DROPSEQUENCEEDGE_OWNER.'||SEQUENCE_NAME||';'                                   
--------------------------------------------------------------------------------
drop sequence edge_owner.COMMENT_HISTORY_SEQ;                                   
drop sequence edge_owner.DATA_AGREEMENT_SEQ;                                    
drop sequence edge_owner.EDGE_BATCH_SEQ;                                        
drop sequence edge_owner.EDGE_JOB_EXECUTION_SEQ;                                
drop sequence edge_owner.EDGE_JOB_RMT_CMD_SEQ;                                  
drop sequence edge_owner.EDGE_SERVER_DETAIL_SEQ;                                
drop sequence edge_owner.JOB_EXECUTION_SEQ;                                     
drop sequence edge_owner.ORGANIZATION_SEQ;                                      
drop sequence edge_owner.PHYSICAL_DOCUMENT_FILE_SEQ;                            
drop sequence edge_owner.REFDATA_VER_SEQ;                                       
drop sequence edge_owner.SERVER_REQUEST_ERROR_LOG_SEQ;                          
drop sequence edge_owner.SERVER_REQUEST_POC_SEQ;                                
drop sequence edge_owner.SERVER_REQUEST_SEQ;                                    
drop sequence edge_owner.SERVER_REQUEST_STATUS_SEQ;                             
drop sequence edge_owner.SQL_DOCUMENT_FILE_SEQ;                                 
drop sequence edge_owner.SQL_INVENTORY_SEQ;                                     
