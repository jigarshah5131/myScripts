set linesize 120
set feedback off
column username format a10
column sid format 99999
column serial# format 999999
column SQL_TEXT format a64
col When form a8 head "When"

prompt
prompt
prompt SQL Info (If Any)
prompt =================

Select distinct decode(a.LOCKWAIT, NULL, 'Holding', 'Waiting') sidstatus,
 a.SID, a.SERIAL#, a.USERNAME, a.COMMAND, a.STATUS,
       decode(a.SQL_ADDRESS, '00', 'Previous', 'Current') when,
       b.SQL_TEXT , b.hash_value,b.sql_id
From gv$session a, gv$sql b
Where a.SID = &sid
and a.status='ACTIVE'
And b.ADDRESS = hextoraw(decode(a.SQL_ADDRESS,'00',a.PREV_SQL_ADDR,a.SQL_ADDRESS
))
/
