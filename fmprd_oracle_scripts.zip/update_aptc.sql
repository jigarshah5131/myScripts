set SERVEROUTPUT ON FORMAT WRAPPED
set APPINFO ON
SET VERIFY OFF

SET FEEDBACK OFF
SET TERMOUT OFF

column date_column new_value today_var
column scriptname new_value thescriptname;
column sessionname new_value sessionname;
column dbname new_value dbname;
select 
      SUBSTR(sys_context('USERENV', 'MODULE'), instr(sys_context('USERENV', 'MODULE'), ' ') +1) || '_' ||  sys_context('USERENV','SESSION_USER') || '_' ||sys_context('USERENV','DB_NAME')  || '_'|| to_char(sysdate, 'yyyymmdd') date_column,
      sys_context('USERENV', 'MODULE') scriptname,
      sys_context('USERENV','SESSION_USER') sessionname,
      sys_context('USERENV','DB_NAME') dbname
from dual;

SPOOL &today_var..log

SET VERIFY ON
SET FEEDBACK ON
SET TERMOUT On
SET ECHO ON

insert into appdba_util.scriptinventory (
SCRIPTNAME,
CREATEDATE,
SCHEMANAME,
DATABASE,
ROLLBACKIND,
FAILUREIND,
localGlobalInd)
values
('&thescriptname',
sysdate,
'&sessionname',
'&dbname',
'N',
'N',
'G');
commit;

/*Before expecting 1 row to return with STARTED status */
select * from eps_owner.batchprocesslog where batchBusinessId = '820PRELIM20180906001';

/* Update PPR Status from STARTED to FAILED.*/
update eps_owner.BatchProcessLog
set JOBSTATUSCD = 'FAILED',
LASTMODIFIEDBY = 'FMBatchOps', 
LASTMODIFIEDDATETIME = SYSTIMESTAMP
where batchBusinessId = '820PRELIM20180906001';

commit;

/*After expecting 1 row to return with FAILED status */
select * from eps_owner.batchprocesslog where batchBusinessId = '820PRELIM20180906001';

spool off 

