set lines 150 pages 0

 --SELECT text FROM table(rdsadmin.rds_file_util.read_text_file('DATA_PUMP_DIR','FMI1B_EPS_OWNER_IMP.log'));
 SELECT text FROM table(rdsadmin.rds_file_util.read_text_file('DATA_PUMP_DIR','FMPRD_EPS_OWNER_IMP_100618.log'));
