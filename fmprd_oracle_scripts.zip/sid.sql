clear columns
set lines 80
set pages 1000
col Server_Program format a40
col Remote_Program format a40
col Serial# format a10
col SID format a10
select /*+ ORDERED */
           a.spid Server_PID,
       a.username Server_Username,
       b.module Module,
       b.action Action,
       b.status Status,
       to_char(b.sid) "SID",
       a.program Server_Program,
       a.pga_used_mem,
       b.process Remote_PID,
       b.osuser Remote_Username,
       to_char(b.serial#) Serial#,
       b.sql_id sqlid,
       b.sql_hash_value,
       b.sql_child_number,
       b.event,
       b.program Remote_Program,
       to_char(b.logon_time,'DD-MON-YY HH24:MI:SS') logon_time,
       to_char(sysdate - (last_call_et/86400),'DD-MON-YY HH24:MI') Last_call
from v$session b, v$process a where addr = paddr and
sid = '&sid'
/
clear col
