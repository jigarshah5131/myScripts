alter table EDGE_OWNER.REFDATA_VERSION_FILE_INFO drop constraint REGA_102;                                                                            
alter table EDGE_OWNER.EDGE_REFDATA_FILE drop constraint REGA_69;                                                                                     
alter table EDGE_OWNER.PHYSICAL_DOCUMENT_FILE_STATUS drop constraint REG_44;                                                                          
alter table EDGE_OWNER.EDGE_JOB_RMT_CMD_FILE drop constraint REG_48;                                                                                  

