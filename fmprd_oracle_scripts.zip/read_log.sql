SELECT text FROM table(rdsadmin.rds_file_util.read_text_file('DATA_PUMP_DIR','FMPRE_EPS_OWNER_IMP_090718.log'));
