alter session set current_schema=eps_owner;
insert into sbmfilearchiveblobopera
select
         sbmfileinfoid
         ,x.sbmxml.getblobval(NLS_CHARSET_ID('AL32UTF8')) sbmxml
         ,sbmfilecreatedatetime
         ,createdatetime
         ,createby
         ,lastmodifieddatetime
         ,LASTMODIFIEDBY
         ,sbmfilenm
         ,sbmfileid
         ,sbmfilenum
         ,tradingpartnerid
         ,tenantnum
         ,coverageyear
         ,issuerfilesetid
         ,issuerid
         ,subscriberstatecd
from sbmfilearchive x where sbmfileinfoid in (9890);
