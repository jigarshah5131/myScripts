   set markup HTML ON -
     HEAD -
        "<style type='text/css'> -
        body {font:10pt Calibri; color:#000000; background:#ffffff;} -
        p {font:10pt Arial,Helvetica,sans-serif; color:black; background:White;} -
        table,tr,td {border:1px solid black; font:10pt Calibri;color:#000000; background:#ffffff;word-wrap:break-word;} -
        table {border-collapse: collapse;table-layout:fixed;width:900px;} -
        th {border:1px solid black; font:bold 11pt Calibri;text-align:center;white-space:wrap;width:200px; height:40px;color:#FFFFFF;background:#4169E1;word-wrap:break-word;} -
        h1 {font:bold 14pt Calibri; color:#000000; background-color:#ffffff; border-bottom:1px solid #cccc99; margin-top:0pt;} -
        h2 {font:bold 10pt Arial,Helvetica,Geneva,sans-serif; color:#FF0000; display:inline; background-color:#ffffff;} -
      </style> -
       <title>Logical Dictionary</title> -
        <H1 align='left'> EPS Logical Dictionary </H1>" -
        BODY "" -
        TABLE " style='width:71%' border='1' summary='Script output'" -
        SPOOL  ON ENTMAP ON PREFORMAT  OFF
