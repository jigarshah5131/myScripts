   set markup HTML ON -
     HEAD -
      "<style type='text/css'> -
        body {font:10pt Calibri; color:#000000; background:#ffffff;} -
        p {font:10pt Arial,Helvetica,sans-serif; color:black; background:White;} -
        table {border-collapse: collapse;table-layout:fixed;width:700px;} -
        table,tr,td {border:1px solid black; font:10pt Calibri;color:#000000; background:#ffffff;width:125px;word-wrap:break-word;} -
        th {border:1px solid black; font:bold 11pt Calibri;text-align:center;white-space:wrap; width:125px;height:70px;color:#FFFFFF; -
            background:#4169E1;word-wrap:break-word} -
        h1 {font:bold 14pt Calibri; color:#000000; background-color:#ffffff; border-bottom:1px solid #cccc99; margin-top:0pt;} -
        h2 {font:bold 10pt Arial,Helvetica,Geneva,sans-serif; color:#FF0000; display:inline; background-color:#ffffff;} -
      </style> -
       <title>SHOP Metrics</title> -
        <H1 align='left'> 2. &nbsp;&nbsp;Employer Applications Submitted to Issuers, by month (active, cancelled/terminated, Non-Payment)</H1> -
        " TABLE " border='1' summary='Script output'" -
        SPOOL  ON ENTMAP ON PREFORMAT  OFF
