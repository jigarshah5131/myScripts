rem * to get the dependencies of the table

undef table
undef owner
clear buffer
clear col
clear break

set show off
set verify off
set long 500000
set lines 130
col column_name format a30
col owner format a20
col name format a30
col type format a20
col table_name format a30
col constraint_name format a30
col r_constraint_name format a30
col synonym_name format a30
col grantee format a30
col privilege format a30
col index_name format a30
col data_default format a15

Prompt  Owner * &&owner_name    **** Table Name * &&table_name *

Prompt ******* Child tables *******
Prompt

select owner, status,table_name ,constraint_name ,r_constraint_name from dba_constraints where
  r_constraint_name in
  (
  select constraint_name from dba_constraints where
  table_name=upper('&&table_name') and owner=upper('&&owner_name')
  and constraint_type in ('U','P')
  )
  and r_owner=upper('&&owner_name')
;


Prompt ******* Parent tables *******
Prompt

select v1.owner, v1.table_name ,v1.constraint_name,v2.r_constraint_name from
  (select owner, table_name, constraint_name from dba_constraints where
  constraint_type in ('P','U')) v1,
  (select r_constraint_name,r_owner from dba_constraints where
  table_name=upper('&&table_name') and owner=upper('&&owner_name')) v2
  where v1.owner=v2.r_owner
  and v1.constraint_name=v2.r_constraint_name
;

Prompt ******* Unique constraints ******
Prompt

select constraint_name, status from dba_constraints where
  table_name=upper('&&table_name') and owner=upper('&&owner_name')
  and constraint_type='U'
;

Prompt ******* Primary key ******
Prompt

select constraint_name, status from dba_constraints where
  table_name=upper('&&table_name') and owner=upper('&&owner_name')
  and constraint_type='P'
;

Prompt ****** Check constraints ******
Prompt

select constraint_name, status from dba_constraints where
  table_name=upper('&&table_name') and owner=upper('&&owner_name')
  and constraint_type='C'
;
col column_name format a30
col data_default format a15
Prompt ****** Column default values ******
Prompt
select substr(column_name,0,30), data_default
  from dba_tab_columns where
  table_name=upper('&&table_name') and owner=upper('&&owner_name')
  and data_default is not null
;

Prompt ****** All  indexes ******
Prompt

select owner, index_name, uniqueness from dba_indexes where
  table_name=upper('&&table_name') and table_owner=upper('&&owner_name')
;

Prompt ****** Table grants ******
Prompt

select grantee, privilege, grantable from dba_tab_privs where
  table_name=upper('&&table_name') and owner=upper('&&owner_name')
;

Prompt ****** Synonyms ******
Prompt

select owner, synonym_name from dba_synonyms where
  table_name=upper('&&table_name') and table_owner=upper('&&owner_name')
;


Prompt ******* PL/SQL dependent objects and views ******
Prompt

select owner, name, type from dba_dependencies where
  referenced_name=upper('&&table_name') and referenced_owner=upper('&&owner_name')
  and referenced_type='TABLE'
;

Prompt ******* The Triggers ******
Prompt

select owner, trigger_name ,status from dba_triggers where
  table_name=upper('&&table_name') and table_owner=upper('&&owner_name')
;
