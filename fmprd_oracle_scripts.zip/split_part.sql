set SERVEROUTPUT ON FORMAT WRAPPED
set APPINFO ON
SET VERIFY OFF

SET FEEDBACK OFF
SET TERMOUT OFF

column date_column new_value today_var
column scriptname new_value thescriptname;
column sessionname new_value sessionname;
column dbname new_value dbname;
select 
	SUBSTR(sys_context('USERENV', 'MODULE'), instr(sys_context('USERENV', 'MODULE'), ' ') +1) || '_' ||  sys_context('USERENV','SESSION_USER') || '_' ||sys_context('USERENV','DB_NAME')  || '_'|| to_char(sysdate, 'yyyymmdd') date_column,
  	sys_context('USERENV', 'MODULE') scriptname,
	sys_context('USERENV','SESSION_USER') sessionname,
	sys_context('USERENV','DB_NAME') dbname
from dual;

SPOOL &today_var..log

SET VERIFY ON
SET FEEDBACK ON
SET TERMOUT On
SET ECHO ON

insert into appdba_util.scriptinventory (
SCRIPTNAME,
CREATEDATE,
SCHEMANAME,
DATABASE,
ROLLBACKIND,
FAILUREIND,
localGlobalInd)
values
('&thescriptname',
 sysdate,
 '&sessionname',
 '&dbname',
 'N',
 'N',
 'G');
commit;

-- 08/03/2018 SSC Modified script to create partitions for issuers prior to transition.
-- The first cursor in this script contains the 10 issuers (21032, 28052, 31070, 49375, 54724, 63312, 66699, 76680, 87269, 97879)
-- from the Transition_Issuer_Template_provided by Devin Taylor.
-- After this script has been run, it will be updated with the 10 issuers from
-- the transition template to create partitions for their data.

declare
cursor c1 is 
select '21032' issid from dual union 
select '28052' issid from dual union
select '31070' issid from dual union 
select '49375' issid from dual union
select '54724' issid from dual union
select '63312' issid from dual union 
select '66699' issid from dual union
select '76680' issid from dual union 
select '87269' issid from dual union
select '97879' issid from dual;

exec_text varchar(2000);
part_text varchar(100);
begin

for c1rec in c1 loop
    part_text := 'HIOS' || C1REC.ISSID;
    exec_text :='alter table policypaymenttrans split partition  hiosdefault values ('''||c1rec.issid||''') into ( partition HIOS'||C1REC.issid||',partition hiosdefault) UPDATE GLOBAL INDEXES';
    DBMS_OUTPUT.PUT_LINE(exec_text);
    execute immediate exec_text;
    DBMS_STATS.GATHER_TABLE_STATS(USER, 'POLICYPAYMENTTRANS', PARTNAME=>PART_TEXT, estimate_percent => dbms_stats.auto_sample_size,method_opt => 'for all columns size skewonly', degree => 4,cascade => true);
    DBMS_OUTPUT.PUT_LINE('Stats gathered for ' || part_text);
end loop;
END;
/
spool off
