BEGIN 
  DBMS_MONITOR.SESSION_TRACE_ENABLE(
    session_id => 25853 
  , serial_num => 89448
  , waits      => true
  , binds      => false);
END;
/
/**
BEGIN
  DBMS_MONITOR.SESSION_TRACE_DISABLE(
    session_id => 25853
  , serial_num => 45056);
END;
/
**/
	
1) How did you use dbms_monitor to trace (SQL_TRACE) impdp worker process (DW00) ? 

2) For trace files location, you need to query v$DIAG_INFO 

To find all trace files for the current instance: 

Submit the following query: 

SELECT VALUE FROM V$DIAG_INFO WHERE NAME = 'Diag Trace'; 

To determine the trace file for each Oracle Database process: 

Submit the following query: 

SELECT PID, PROGRAM, TRACEFILE FROM V$PROCESS where tracefile like '%<SPID>%';
