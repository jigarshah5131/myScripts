set lines 160
col segment_name format a30
col table_name format a30
col column_name format a30
col owner format a15
col object_name format a30
col value format a30
select segment_name,bytes/1024/1024 from dba_segments where segment_name='TRANSMSG' ;
