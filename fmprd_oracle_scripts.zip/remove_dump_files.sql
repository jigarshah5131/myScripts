set serveroutput on  echo on feed on
spool /tmp/remove_expdump_files.lst
begin
 for i in (select filename from (select * from table(RDSADMIN.RDS_FILE_UTIL.LISTDIR('DATA_PUMP_DIR')) order by mtime) where filename like '&1%')
 loop
  utl_file.fremove('DATA_PUMP_DIR',i.filename);
 end loop;
end;
/
spool off
exit
