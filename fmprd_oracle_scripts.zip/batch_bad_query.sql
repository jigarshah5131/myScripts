spool /tmp/a.txt
select count(*) From
(
SELECT btm.EXCHANGEPOLICYID
                                      || ','
                                      || btm.SOURCEVERSIONDATETIME
                                      || ','
                                      || btm.SOURCEVERSIONID
                                      || ','
                                      || btm.SUBSCRIBERSTATECD AS LINE_OF_TEXT
                                    FROM BATCHTRANSMSG btm
                                    WHERE btm.SOURCEVERSIONDATETIME >= TO_TIMESTAMP('15-11-2018 17:59:59.628', 'dd-mm-yyyy hh24:mi:ss.FF')
                                    AND btm.SOURCEVERSIONDATETIME    < TO_TIMESTAMP('16-12-2018 02:59:59.617', 'dd-mm-yyyy hh24:mi:ss.FF')
        --                            ORDER BY btm.SOURCEVERSIONDATETIME ASC
)
/
spool off
