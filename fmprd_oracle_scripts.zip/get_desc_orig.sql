SET MARKUP HTML ON SPOOL ON
SET NULL 'NO ROWS SELECTED'
set tab off
set trims off
set heading off
col "Entity Name" format a30
col "Attribute Name" format a30
col Domain format a20
col "Null Option Type" format a15
-- set pages 90
set lines 100
set feed off
spool EPS_Data_Dict.html
--break on TABLE_NAME skip 1 
--TTITLE COL 110 FORMAT 9 "Page:" SQL.PNO

SELECT 'Logical Dictionary' from dual;
set heading on
SELECT utc.TABLE_NAME ,
         utc.COLUMN_NAME ,
         utc.DATA_TYPE || CASE DATA_TYPE
        WHEN 'VARCHAR2' THEN '('||DATA_LENGTH||')'
        WHEN 'NUMBER' THEN  CASE
                          WHEN DATA_PRECISION IS NOT NULL
                          THEN  '('||DATA_PRECISION||CASE
                                                     WHEN DATA_SCALE <>0
                                                     THEN ','||DATA_SCALE END
                          END||CASE WHEN DATA_PRECISION IS NOT NULL
                               THEN ')' END
       END DATA_LENGTH , 
	CASE NULLABLE
	  WHEN 'Y' THEN 'Null'
          ELSE 'Not Null'
        END "Null Option Type"
 FROM  DBA_TAB_COLUMNS utc
 WHERE utc.OWNER ='EPS_OWNER'
/
spool off
