set lines 120
set pages 1000
col username format a10
col module format a20
col event format a50
select sid,program,module,username,event ,status from gv$session where serial#!=1 and username!='SYS' and event not like 'Streams%' and program like '%' and status='ACTIVE'
/
