col "Entity Name" format a30
col "Attribute Name" format a30
col Domain format a15
col "Null Option Type" format a20

-- set pages 90
set lines 100
set feed off
set pages 1000
break on "Entity Name" skip 1

SELECT utc.TABLE_NAME "Entity Name",
         utc.COLUMN_NAME "Attribute Name",
         utc.DATA_TYPE || CASE DATA_TYPE
        WHEN 'VARCHAR2' THEN '('||DATA_LENGTH||')'
        WHEN 'NUMBER' THEN  CASE
                          WHEN DATA_PRECISION IS NOT NULL
                          THEN  '('||DATA_PRECISION||CASE
                                                     WHEN DATA_SCALE <>0
                                                     THEN ','||DATA_SCALE END
                          END||CASE WHEN DATA_PRECISION IS NOT NULL
                               THEN ')' END
       END "Domain" , 
	CASE NULLABLE
	  WHEN 'Y' THEN 'Null'
          ELSE 'Not Null'
        END "Null Option Type"
 FROM  DBA_TAB_COLUMNS utc
 WHERE utc.OWNER ='EPS_OWNER'
 order by utc.table_name
/
spool off
