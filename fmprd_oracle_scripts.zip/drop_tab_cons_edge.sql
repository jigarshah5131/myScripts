set pages 100 lines 150 
spool drop_cons_1_edge.sql
select 'alter table EDGE_OWNER.'
       || table_name
       || ' drop constraint '
       || constraint_name
       ||';' constraint_disable
from dba_constraints
where constraint_type = 'R'
and status = 'ENABLED'
and r_constraint_name in
 (
   select constraint_name
   from dba_constraints
   where constraint_type in ('P', 'U')
   and table_name in ('PHYSICAL_DOCUMENT_FILE','REFDATA_VERSION_FILE_INFO','EDGE_REFDATA_FILE','PHYSICAL_DOCUMENT_FILE_STATUS','EDGE_JOB_RMT_CMD_FILE') and owner ='EDGE_OWNER'
 )
/
spool off
