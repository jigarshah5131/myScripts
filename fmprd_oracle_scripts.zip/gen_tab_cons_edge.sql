set pages 1000 lines 200
spool gen_cons_1_edge.sql
select  'alter table EDGE_OWNER.'|| t1_table_name
     || ' add constraint ' || t1_constraint_name
     || ' foreign key (' || t1_column_names || ')'
     || ' references EDGE_OWNER.' || t2_table_name
     || '(' || t2_column_names || ');' FK_script
  from
    (select a.table_name t1_table_name
      , a.constraint_name t1_constraint_name
      , b.r_constraint_name t2_constraint_name
      -- Concatenate columns to handle composite
      -- foreign keys
      , listagg(a.column_name,', ')
            within group (order by a.position)
            as t1_column_names
    from dba_cons_columns a
       , dba_constraints b
    where a.constraint_name = b.constraint_name
    and b.constraint_type = 'R'
    and a.owner=b.owner
    and a.owner='EDGE_OWNER'
    group by a.table_name
           , a.constraint_name
           , b.r_constraint_name
    ) t1,
    (select a.constraint_name t2_constraint_name
      , a.table_name t2_table_name
      -- Concatenate columns for PK/UK referenced
      -- from a composite foreign key
      , listagg(a.column_name,', ')
            within group (order by a.position)
            as t2_column_names
    from dba_cons_columns a, dba_constraints b
    where a.constraint_name = b.constraint_name
    and b.constraint_type in ( 'P', 'U' )
    and a.owner=b.owner
    and a.owner='EDGE_OWNER'
    group by a.table_name
           , a.constraint_name ) t2
where t1.t2_constraint_name = t2.t2_constraint_name
  and t2.t2_table_name in ('PHYSICAL_DOCUMENT_FILE','REFDATA_VERSION_FILE_INFO','EDGE_REFDATA_FILE','PHYSICAL_DOCUMENT_FILE_STATUS','EDGE_JOB_RMT_CMD_FILE')
/
spool off
