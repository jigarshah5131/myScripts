SET NEWPAGE 0
SET SPACE 0
SET LINESIZE 5000
SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET VERIFY OFF
SET HEADING OFF
SET MARKUP HTML OFF SPOOL OFF
SET LINESIZE 150
spool run_drop_sequences.sql
SELECT 'drop sequence '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||';' from dba_sequences where sequence_owner='&1';
spool off
@run_drop_sequences.sql
exit
