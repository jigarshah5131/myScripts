#!/bin/bash
#-x
#Usage:
#scriptfile dump_location DB_Username password sid schema_name
export DIRECTORY=`dirname $0`
export EXP_START_TIME=$1  ## Format shoud be like this "08-08-2019 10:10:00"
export EXPDIR=DATA_PUMP_DIR
export DBUSERNAME=refresh
export DBPASSWORD=Cms_FM_Refresh_2019
export SERVICE_NAME=fmpre2
export TGTSERVICE_NAME=fmpre2
export SCHEMA_NAME=ECM_OWNER
export TFILE=`echo /tmp/nohup.$$.tmp`
export STARTTIME=`date`
export DATEFORMAT=`date +%Y%m%d_%Hh%Mm%Ss`
#export ORACLE_HOME=`cat /etc/oratab|grep ^${ORACLE_SID}:|cut -d':' -f2`
export EXPLOG=expdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`.log
export IMPLOG=impdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`.log
export EXPDUMPFILES=expdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`_%u.dmp
export EXPDUMPPARTIAL=expdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`
#export EXPDUMPPARTIAL=expdp_ECM_OWNER_$SERVICE_NAME_20190806_17h38m03s
#export EXPORTTIME="08-08-2019 10:10:00"
export EXPORTTIME="${EXP_START_TIME:-systimestamp}"
export t=0
export S3_BUCKETNAME=datapumpdirfiles-prod
export PARALLEL=8
export DATAPUMPDIR=DATA_PUMP_DIR
#export PATH=$PATH:$ORACLE_HOME/bin


echo "INFO: Starting export dump for ECM_OWNER Schema"

if [ -z "$EXP_START_TIME" ]
  then
  echo "INFO: Start time is NOT provided. Using System default timestamp ${EXPORTTIME}."
  expdp $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME directory=$EXPDIR dumpfile=$EXPDUMPFILES  logfile=$EXPLOG schemas=$SCHEMA_NAME compression=all reuse_dumpfiles=yes FLASHBACK_TIME=${EXPORTTIME}
else
  echo "INFO: Start time is provided as parameter. Using start time as ${EXPORTTIME}"
  expdp $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME directory=$EXPDIR dumpfile=$EXPDUMPFILES  logfile=$EXPLOG schemas=$SCHEMA_NAME compression=all reuse_dumpfiles=yes FLASHBACK_TIME=\"TO_TIMESTAMP\(\'$EXPORTTIME\', \'DD-MM-YYYY HH24:MI:SS\'\)\"
fi
  

status=$?

echo "INFO: Checking success of Export dump"

echo "INFO: Export dump status is $status"

sucmsgcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME @read_explog.sql "$EXPLOG"|grep -E 'Job.*SYS_EXPORT_SCHEMA.*successfully' |wc -l)

echo "INFO: Successmessage count is $sucmsgcnt"

if [[ $status != 0 ]]; then exit $status; fi

#echo -ne "set pages 1000 \nset feed off\n set head off \nselect filename from (select * from table(RDSADMIN.RDS_FILE_UTIL.LISTDIR('DATA_PUMP_DIR')) order by mtime) where filename like '${EXPDUMPPARTIAL}%dmp';"|sqlplus -s refresh/$STR@$SERVICE_NAME


echo "INFO: Checking count of Export dump files"

expdumpcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@${SERVICE_NAME} <<< "select filename from table (rdsadmin.rds_file_util.listdir('DATA_PUMP_DIR')) where filename like '${EXPDUMPPARTIAL}%dmp';" |grep -E "exp.*dmp" |wc -l)
echo INFO: Total number of export dump files are $expdumpcnt

echo "INFO: Uploading Export dump files to S3 Bucket ${S3_BUCKETNAME}"

pretaskid=$(sqlplus  -s $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME @upload_to_s3_integration.sql ${S3_BUCKETNAME} ${EXPDUMPPARTIAL} ${SERVICE_NAME})

echo "INFO: PRETASK ID is ${pretaskid}"

taskid=${pretaskid//$'\n'/}
export taskid

echo "INFO: TASK ID is ${taskid}"

echo "INFO: TASK ID is dbtask-${taskid}.log"

echo "INFO: Logfile for the Upload task is dbtask-${taskid}.log"

echo "INFO: Going to while loop to wait for the upload task to be completed"

while [ $t -le 400 ]
do
  echo "INFO: Running dumpcount and sucmsgcnt to evaluate if the files were uploaded to S3 bucket ${S3_BUCKETNAME}"

  dumpcount=$(sqlplus  -s $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME @read_dbtask.sql "dbtask-${taskid}.log" |grep "File #"|grep dmp |wc -l)
  sucmsgcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME @read_dbtask.sql "dbtask-${taskid}.log"|grep "The task finished successfully" |wc -l)

   if [ ${dumpcount} -eq ${expdumpcnt} ] && [ ${sucmsgcnt} -eq 1 ]
     then
        echo "INFO: dump file count is $dumpcount"
        echo "INFO: Successful message count is $sucmsgcnt"
        echo "INFO: files transferred successfully"
        break
   else
        echo "INFO: Still uploading, have patience !!"
        echo "INFO: dump file count is $dumpcount"
        echo "INFO: Successful message count is $sucmsgcnt"
   fi
  echo "INFO: So far $t of 400 seconds slept"
  t=$(( $t + 20 ))
  echo "INFO: Going to sleep for 20 seconds"
  sleep 20
done

echo "INFO: Recheck if files are really uploaded and Succcessful message is in the logfile"
  dumpcount=$(sqlplus  -s $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME @read_dbtask.sql "dbtask-${taskid}.log" |grep "File #"|grep dmp |wc -l)
  sucmsgcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME @read_dbtask.sql "dbtask-${taskid}.log"|grep "The task finished successfully" |wc -l)

if [ ${dumpcount} -eq ${expdumpcnt} ] && [ ${sucmsgcnt} -eq 1 ]
  then
    echo  "INFO: Files have been uploaded successfully"
    touch ${DIRECTORY}/${EXPDUMPPARTIAL}-${expdumpcnt}
else
    echo  "INFO: Upload to the S3 is failed. Please investigate"
    exit 1
fi


#IMPecho "INFO:  Setting up Target on $TGTSERVICE_NAME"
#IMP
#IMPecho "INFO: Downloading Export dump files from S3 Bucket ${S3_BUCKETNAME} to ${DATAPUMPDIR} directory"
#IMP
#IMPpretaskid=$(sqlplus  -s $DBUSERNAME/$DBPASSWORD@${TGTSERVICE_NAME} @download_from_s3_data_dump.sql ${S3_BUCKETNAME} "${SERVICE_NAME}/${EXPDUMPPARTIAL}" ${DATAPUMPDIR})
#IMP
#IMPecho "INFO: PRETASK ID is ${pretaskid}"
#IMP
#IMPtaskid=${pretaskid//$'\n'/}
#IMP
#IMPexport taskid
#IMP
#IMP
#IMPecho "INFO: TASK ID is ${taskid}"
#IMP
#IMPecho "INFO: TASK ID is dbtask-${taskid}.log"
#IMP
#IMPecho "INFO: Logfile for the Download task is dbtask-${taskid}.log"
#IMP
#IMP## Resetting t back to 0
#IMPt=0
#IMPwhile [ $t -le 900 ]
#IMPdo
#IMP  echo "INFO: Running dumpcount and sucmsgcnt to evaluate if the files were downloaded from S3 bucket to  ${DATAPUMPDIR}"
#IMP
#IMP  dumpcount=$(sqlplus  -s $DBUSERNAME/$DBPASSWORD@$TGTSERVICE_NAME @read_dbtask.sql "dbtask-${taskid}.log" |grep "The task successfully downloaded the Amazon S3 object or objects from bucket name"|grep dmp |wc -l)
#IMP  sucmsgcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@$TGTSERVICE_NAME @read_dbtask.sql "dbtask-${taskid}.log"|grep "The task finished successfully" |wc -l)
#IMP
#IMP   if [ ${dumpcount} -eq ${expdumpcnt} ] && [ ${sucmsgcnt} -eq 1 ]
#IMP     then
#IMP        echo "dump file count is $dumpcount"
#IMP        echo "Successful message count is $sucmsgcnt"
#IMP        echo "files transferred successfully"
#IMP        break
#IMP   else
#IMP        echo
#IMP        echo "Still downloadng, have patience !!"
#IMP        echo "dump file count is $dumpcount"
#IMP        echo "Successful message count is $sucmsgcnt"
#IMP   fi
#IMP  echo "So far $t of 900 seconds slept"
#IMP  t=$(( $t + 60 ))
#IMP  echo "Going to sleep for 60 seconds"
#IMP  sleep 60
#IMPdone
#IMP
#IMPif [[ $status != 0 ]]
#IMP  then
#IMP    exit $status
#IMPelse
#IMP  echo "INFO: Building drop sequences script and running it in $TGTSERVICE_NAME"
#IMP  sqlplus -s $DBUSERNAME/$DBPASSWORD@$TGTSERVICE_NAME @drop_sequences.sql "${SCHEMA_NAME}"
#IMP  echo "INFO: Starting import into $TGTSERVICE_NAME"
#IMP  impdp $DBUSERNAME/$DBPASSWORD@$TGTSERVICE_NAME directory=$DATAPUMPDIR dumpfile=${EXPDUMPFILES} logfile=${IMPLOG} TABLE_EXISTS_ACTION=replace schemas=${SCHEMA_NAME} PARALLEL=$PARALLEL
#IMPfi
#IMP
#IMP
#IMP#sucremfilemsg=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME @remove_dump_files_rds.sql "${EXPDUMPPARTIAL}")
#IMPsqlplus -s $DBUSERNAME/$DBPASSWORD@$SERVICE_NAME @remove_dump_files_rds.sql "${EXPDUMPPARTIAL}"
#IMPstatus=$?
#IMPecho "Export Dump file removal status is $status"
#IMP
#IMPecho "INFO: Dump files count after removal"
#IMP
#IMPexpdumpcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@fmimpl1b <<< "select filename from table (rdsadmin.rds_file_util.listdir('DATA_PUMP_DIR')) where filename like '${EXPDUMPPARTIAL}%dmp';" |grep -E "exp.*dmp" |wc -l)
#IMP
#IMPecho Total number of export dump files after delete are $expdumpcnt
#IMP
