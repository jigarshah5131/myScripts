set lines 160
col filename format a100
col mtime format a30
select mtime,filename from table(rdsadmin.rds_file_util.listdir('DATA_PUMP_DIR')) where filename like 'exp%' order by mtime;
