#!/bin/bash
#-x
#Usage:
#scriptfile dump_location DB_Username password sid schema_name
export EXPDIR=DATA_PUMP_DIR
export DBUSERNAME=refresh
export DBPASSWORD=Cms_FM_Refresh_2019
export SERVICE_NAME=fmpre
export TGTSERVICE_NAME=fmpre
export SCHEMA_NAME=ECM_OWNER
export TFILE=`echo /tmp/nohup.$$.tmp`
export STARTTIME=`date`
export DATEFORMAT=`date +%Y%m%d_%Hh%Mm%Ss`
#export ORACLE_HOME=`cat /etc/oratab|grep ^${ORACLE_SID}:|cut -d':' -f2`
export EXPLOG=expdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`.log
export EXPDUMPFILES=expdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`_%u.dmp
#export EXPDUMPPARTIAL=expdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`
export EXPDUMPPARTIAL="expdp_ECM_OWNER_fmpre_20190927_20h29m37s"
export EXPORTTIME="08-08-2019 10:10:00"
export t=0
export S3_BUCKETNAME=datapumpdirfiles-prod
export PARALLEL=32
export DATAPUMPDIR=DATA_PUMP_DIR


echo "INFO:  Setting up Target on $TGTSERVICE_NAME"

echo "INFO: Downloading Export dump files from S3 Bucket ${S3_BUCKETNAME} to ${DATAPUMPDIR} directory"

pretaskid=$(sqlplus  -s $DBUSERNAME/$DBPASSWORD@${TGTSERVICE_NAME} @download_from_s3_data_dump.sql ${S3_BUCKETNAME} "${SERVICE_NAME}/${EXPDUMPPARTIAL}" ${DATAPUMPDIR})

echo "INFO: PRETASK ID is ${pretaskid}"

taskid=${pretaskid//$'\n'/}

export taskid

export expdumpcnt=1
echo "INFO: TASK ID is ${taskid}"

echo "INFO: TASK ID is dbtask-${taskid}.log"

echo "INFO: Logfile for the Download task is dbtask-${taskid}.log"

while [ $t -le 900 ]
do
  echo "INFO: Running dumpcount and sucmsgcnt to evaluate if the files were downloaded from S3 bucket to  ${DATAPUMPDIR}"

  dumpcount=$(sqlplus  -s $DBUSERNAME/$DBPASSWORD@$TGTSERVICE_NAME @read_dbtask.sql "dbtask-${taskid}.log" |grep "The task successfully downloaded the Amazon S3 object or objects from bucket name"|grep dmp |wc -l)
  sucmsgcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@$TGTSERVICE_NAME @read_dbtask.sql "dbtask-${taskid}.log"|grep "The task finished successfully" |wc -l)

   if [ ${dumpcount} -eq ${expdumpcnt} ] && [ ${sucmsgcnt} -eq 1 ]
     then
        echo "dump file count is $dumpcount"
        echo "Successful message count is $sucmsgcnt"
        echo "files transferred successfully"
        break
   else
        echo
        echo "Still downloadng, have patience !!"
        echo "dump file count is $dumpcount"
        echo "Successful message count is $sucmsgcnt"
   fi
  echo "So far $t of 400 seconds slept"
  t=$(( $t + 20 ))
  echo "Going to sleep for 20 seconds"
  sleep 20
done
