SET NEWPAGE 0
SET SPACE 0
SET LINESIZE 5000
SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET VERIFY OFF
SET HEADING OFF
SET MARKUP HTML OFF SPOOL OFF
SELECT rdsadmin.rdsadmin_s3_tasks.download_from_s3(
      p_bucket_name    =>  '&1',
      p_s3_prefix      =>  '&2',
      p_directory_name =>  '&3')
   AS TASK_ID FROM DUAL;
exit
