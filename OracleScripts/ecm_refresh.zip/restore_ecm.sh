#!/bin/bash
#-x
#Usage:
#scriptfile dump_location DB_Username password sid schema_name
export DIRECTORY=`dirname $0`
export EXP_START_TIME=$1  ## Format shoud be like this "08-08-2019 10:10:00"
export EXPDIR=DATA_PUMP_DIR
export DBUSERNAME=refresh
export DBPASSWORD=Cms_FM_Refresh_2019
export SERVICE_NAME=fmpre
export TGTSERVICE_NAME=fmpre
export SCHEMA_NAME=ECM_OWNER
export TFILE=`echo /tmp/nohup.$$.tmp`
export STARTTIME=`date`
export DATEFORMAT=`date +%Y%m%d_%Hh%Mm%Ss`
#export ORACLE_HOME=`cat /etc/oratab|grep ^${ORACLE_SID}:|cut -d':' -f2`
export EXPLOG=expdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`.log
export IMPLOG=impdp_`echo $SCHEMA_NAME`_`echo $SERVICE_NAME`_`echo $DATEFORMAT`.log
export S3_BUCKETNAME=datapumpdirfiles-prod
FILENAME=`ls $DIRECTORY/expdp_ECM_OWNER_${TGTSERVICE_NAME}*`
EXPDUMPPARTIAL=`basename $DIRECTORY/${FILENAME}|awk -F"-" '{print $1}'`
export EXPDUMPFILES=${EXPDUMPPARTIAL}_%u.dmp
expdumpcnt=`basename $DIRECTORY/${FILENAME}|awk -F"-" '{print $2}'`
export t=0
export DATAPUMPDIR=DATA_PUMP_DIR
export sleepint=20

echo "INFO: Setting up Target on ${TGTSERVICE_NAME}"

echo "INFO: Alias of Export Dump file name is ${EXPDUMPPARTIAL}"

echo "INFO: Total number of export dump files are ${expdumpcnt}"

echo "INFO: Downloading Export dump files from S3 Bucket ${S3_BUCKETNAME} to ${DATAPUMPDIR} directory"

pretaskid=$(sqlplus  -s ${DBUSERNAME}/${DBPASSWORD}@${TGTSERVICE_NAME} @${DIRECTORY}/download_from_s3_data_dump.sql ${S3_BUCKETNAME} "${SERVICE_NAME}/${EXPDUMPPARTIAL}" ${DATAPUMPDIR})

echo "INFO: PRETASK ID is ${pretaskid}"

taskid=${pretaskid//$'\n'/}

export taskid


echo "INFO: TASK ID is ${taskid}"

echo "INFO: TASK ID is dbtask-${taskid}.log"

echo "INFO: Logfile for the Download task is dbtask-${taskid}.log"

## Resetting t back to 0
t=0
while [ $t -le 900 ]
 do
 echo "INFO: Running dumpcnt and sucmsgcnt to evaluate if the files were downloaded from S3 bucket to  ${DATAPUMPDIR}"

 dumpcnt=$(sqlplus  -s ${DBUSERNAME}/${DBPASSWORD}@${TGTSERVICE_NAME} @${DIRECTORY}/read_dbtask.sql "dbtask-${taskid}.log" |grep "The task successfully downloaded the Amazon S3 object or objects from bucket name"|grep dmp |wc -l)
 sucmsgcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@$TGTSERVICE_NAME @${DIRECTORY}/read_dbtask.sql "dbtask-${taskid}.log"|grep "The task finished successfully" |wc -l)

   if [ ${dumpcnt} -eq ${expdumpcnt} ] && [ ${sucmsgcnt} -eq 1 ]
     then
        echo "INFO: dump file count is ${dumpcnt}"
        echo "INFO: Successful message count is ${sucmsgcnt}"
        echo "INFO: ${EXPDUMPPARTIAL} is successfully downloaded from S3 bucket ${S3_BUCKETNAME} to ${DATAPUMPDIR}."
        break
   else
        echo
        echo "INFO: Still downloadng, have patience !!"
        echo "INFO: dump file count is ${dumpcnt}"
        echo "INFO: Successful message count is ${sucmsgcnt}"
   fi
  echo "INFO: Going to sleep for ${sleepint} seconds"
  sleep ${sleepint}
  echo "INFO: So far $t of 900 seconds slept"
  t=$(( ${t} + ${sleepint} ))
done

finalexpdumpcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@${SERVICE_NAME} <<< "select filename from table (rdsadmin.rds_file_util.listdir('DATA_PUMP_DIR')) where filename like '${EXPDUMPPARTIAL}%dmp';" |grep -E "exp.*dmp" |wc -l)

echo "INFO: Total number of export dump files after download is ${finalexpdumpcnt}"
status=$?
echo "INFO: Status after downloading export dump is $status"

if [[ $status != 0 ]]
  then
  exit ${status}
elif [[ ${finalexpdumpcnt} -gt 0 ]]
  then
  echo "INFO: Building drop user script and running it in $TGTSERVICE_NAME"
  sqlplus -s $DBUSERNAME/$DBPASSWORD@$TGTSERVICE_NAME @drop_user.sql "${SCHEMA_NAME}"
  echo "INFO: Starting import into $TGTSERVICE_NAME"
  impdp ${DBUSERNAME}/${DBPASSWORD}@${TGTSERVICE_NAME} directory=${DATAPUMPDIR} dumpfile=${EXPDUMPFILES} logfile=${IMPLOG} schemas=${SCHEMA_NAME}
else
  echo "INFO: Something is Not right. Please investigate. Exiting.."
  exit ${status}
fi

sucremfilemsg=$(sqlplus -s ${DBUSERNAME}/${DBPASSWORD}@${TGTSERVICE_NAME} @${DIRECTORY}/remove_dump_files_rds.sql "${EXPDUMPPARTIAL}")
sqlplus -s ${DBUSERNAME}/${DBPASSWORD}@${SERVICE_NAME} @${DIRECTORY}/remove_dump_files_rds.sql "${EXPDUMPPARTIAL}"

status=$?
echo "INFO: Export Dump file removal status is $status"
echo "INFO: Dump files count after removal"

expdumpcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@fmimpl1b <<< "select filename from table (rdsadmin.rds_file_util.listdir('DATA_PUMP_DIR')) where filename like '${EXPDUMPPARTIAL}%dmp';" |grep -E "exp.*dmp" |wc -l)
echo "INFO: Total number of export dump files after delete are ${expdumpcnt}"
mkdir -p ${DIRECTORY}/archive
mv ${DIRECTORY}/expdp_ECM_OWNER_${TGTSERVICE_NAME}* ${DIRECTORY}/archive/ 
