#!/bin/bash
export DBUSERNAME=refresh
export DBPASSWORD=Cms_FM_Refresh_2019
export SERVICE_NAME=fmpre
export TGTSERVICE_NAME=fmpre
export SCHEMA_NAME=ECM_OWNER

DIRECTORY=`dirname $0`
echo $DIRECTORY
FILENAME=`ls $DIRECTORY/expdp_ECM_OWNER*`
echo $FILENAME
EXPDUMPPARTIAL=`basename $DIRECTORY/${FILENAME}|awk -F"-" '{print $1}'`
dumpcount=`basename $DIRECTORY/${FILENAME}|awk -F"-" '{print $2}'`
echo ${EXPORTDUMPPARTIAL}
echo $dumpcount
#echo $DIRECTORY/$EXPORTDUMPPARTIAL
taskid=1569684046694-17143
dumpcount=$(sqlplus  -s ${DBUSERNAME}/${DBPASSWORD}@${TGTSERVICE_NAME} @${DIRECTORY}/read_dbtask.sql "dbtask-${taskid}.log" |grep "The task successfully downloaded the Amazon S3 object or objects from bucket name"|grep dmp |wc -l)
echo $dumpcount

expdumpcnt=$(sqlplus -s $DBUSERNAME/$DBPASSWORD@${SERVICE_NAME} <<< "select filename from table (rdsadmin.rds_file_util.listdir('DATA_PUMP_DIR')) where filename like '${EXPDUMPPARTIAL}%dmp';" |grep -E "exp.*dmp" |wc -l)
echo INFO: Total number of export dump files are $expdumpcnt
echo $expdumpcnt
